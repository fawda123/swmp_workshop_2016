globalVariables(c('.', 'day', 'daydat', 'flo', 'year', 'res', 'nrms_variable', 'nrms_value', 'fits_variable',
  'fits_value', 'bt_norm', 'bt_fits', 'lnres', 'lnQ', 'value', 'taus', 'month', 'i', 'tidfit',
  'rsdnl', 'mod', 'Year', 'mo', 'fake_date', 'flo.x', 'flo.y', 'nrm', 'fit', 'year_dum', 'month2',
  'yrcat', 'mocat', 'matches', 'yr', 'yrchg', 'val', 'xvar', 'one_of'))

#' @importFrom stats AIC approx arima.sim ave coef constrOptim fitted lm median na.omit nobs optim predict quantile resid rnorm sd var
NULL