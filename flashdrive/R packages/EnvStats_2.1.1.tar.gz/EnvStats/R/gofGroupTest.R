gofGroupTest <-
function (object, ...) 
UseMethod("gofGroupTest")
