s.0.m.singly.censored <-
function (r, alf, bet) 
{
    g1.m.singly.censored(r, 0.5, alf, bet)/g2.m.singly.censored(r, 
        0, alf, bet)
}
