summaryStats.character <-
function (object, ...) 
{
    summaryStats.factor(factor(object), ...)
}
